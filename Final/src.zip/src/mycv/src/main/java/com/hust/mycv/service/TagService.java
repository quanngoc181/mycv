package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface TagService {

	void updateTag(CvDto dto);

}
