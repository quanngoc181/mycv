package com.hust.mycv.entity;

public class HitsSource {
	
	private String name;
	
	public HitsSource() {
		super();
	}

	public HitsSource(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
