package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface PositionService {
	
	void updatePosition(CvDto dto);

}
