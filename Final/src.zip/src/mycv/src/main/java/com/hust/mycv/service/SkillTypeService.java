package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface SkillTypeService {

	void updateSkill(CvDto dto);

}
