package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface SchoolService {
	
	void updateSchool(CvDto dto);

}
