package com.hust.mycv.dto;

public class CvSectionDto {
	
	public String name;
	
	public boolean display;
	
	public CvSectionDto() {
		super();
	}

	public CvSectionDto(String name, boolean display) {
		super();
		this.name = name;
		this.display = display;
	}

}
