package com.hust.mycv.dto;

public class ScholarshipDto {

	public String name;

	public String organization;

	public String year;

	public ScholarshipDto() {
		super();
	}

	public ScholarshipDto(String name, String organization, String year) {
		super();
		this.name = name;
		this.organization = organization;
		this.year = year;
	}

}
