package com.hust.mycv.dto;

public class SkillDto {
	
	public String name;

	public float rate;
	
	public SkillDto() {
		super();
	}

	public SkillDto(String name, float rate) {
		super();
		this.name = name;
		this.rate = rate;
	}

}
