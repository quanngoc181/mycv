package com.hust.mycv.dto;

public class UserDto {
	
	public String username;
	
	public String role;
	
	public UserDto() {
		super();
	}

	public UserDto(String username, String role) {
		super();
		this.username = username;
		this.role = role;
	}

}
