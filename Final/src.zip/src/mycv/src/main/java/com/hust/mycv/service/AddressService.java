package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface AddressService {

	void updateAddress(CvDto dto);

}
