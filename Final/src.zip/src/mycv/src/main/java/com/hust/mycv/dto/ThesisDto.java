package com.hust.mycv.dto;

public class ThesisDto {

	public String title;

	public String advisor;

	public String description;

	public ThesisDto() {
		super();
	}

	public ThesisDto(String title, String advisor, String description) {
		super();
		this.title = title;
		this.advisor = advisor;
		this.description = description;
	}

}
