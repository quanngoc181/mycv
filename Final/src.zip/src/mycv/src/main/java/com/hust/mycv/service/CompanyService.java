package com.hust.mycv.service;

import com.hust.mycv.dto.CvDto;

public interface CompanyService {
	
	void updateCompany(CvDto dto);

}
