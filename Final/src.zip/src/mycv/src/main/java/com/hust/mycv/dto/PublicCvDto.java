package com.hust.mycv.dto;

public class PublicCvDto {
	
	public Integer id;
	
	public boolean cvPublic;
	
	public PublicCvDto() {
		super();
	}

	public PublicCvDto(Integer id, boolean cvPublic) {
		super();
		this.id = id;
		this.cvPublic = cvPublic;
	}

}
