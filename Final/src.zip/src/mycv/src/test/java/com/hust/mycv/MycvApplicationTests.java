package com.hust.mycv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MycvApplicationTests {

	@Test
	void contextLoads() {
	}

}
